import { msiteApi } from '../api';
import {
  SHOPS_UPDATE,
  ADDRESS_UPDATE
} from './mutation-type';


export default {
  async shopsUpdate({commit, state}) {
    const result = await msiteApi.getAddress({
      latitude:state.latitude,
      longitude:state.longitude
    })
    console.log(".....")
    commit(SHOPS_UPDATE, result.data)
  },
}