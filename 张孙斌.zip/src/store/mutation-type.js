

export const SHOPS_UPDATE = 'shops_update';

export const ADDRESS_UPDATE = 'address_update';


