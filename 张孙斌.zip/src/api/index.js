import msiteInstance  from './assets/component_instance.js';
import ajaxInstance from './ajax';
import apis from './assets/api-options';
import { axiosHttp } from '../utils';

const msiteApi = axiosHttp(apis, ajaxInstance(msiteInstance));
console.log(axiosHttp);

export {
  msiteApi,
}