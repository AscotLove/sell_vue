import { Toast } from 'vant';

function ajaxInstance(instance) {
  instance.interceptors.request.use(
    (config) => {

console.log(config)
      return config
    },
    (err) => {

      return Promise.reject(err)
    }
  )

  instance.interceptors.response.use(
    (response) => {


      return response
    },
    (err) => {

      return Promise.reject(err)
    }
  )
}

export default ajaxInstance;