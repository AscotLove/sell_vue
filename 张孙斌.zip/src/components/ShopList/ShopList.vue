<template>
  
</template>

<script>
  export default {
    name: "ShopList"
  }
</script>

<style lang="stylus" rel="stylesheet/stylus" scoped>

</style>